#! /bin/bash
g++ -g -std=c++11 "$1" -o "$2"
